export const environment = {
  firebase: {
    projectId: 'angular-sign-up',
    appId: '1:916691174045:web:677a900ca493c7d0e9ca74',
    storageBucket: 'angular-sign-up.appspot.com',
    apiKey: 'AIzaSyAaS6ztStcHbGSznGNBchaa_ZN5B02Zk6c',
    authDomain: 'angular-sign-up.firebaseapp.com',
    messagingSenderId: '916691174045',
  },
  production: true
};
